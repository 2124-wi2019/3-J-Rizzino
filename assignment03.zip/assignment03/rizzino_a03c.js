/* Julie Rizzino
rizzino_a03c.js
INFO 2124
Thoendel
12/17/19 */
let preamble = `When in the course of human events`;
let message = 
`The preamble is: 
\t${preamble}

Does the preamble contain 'a'?
\t${preamble.includes('a')}`;
console.log(message);
